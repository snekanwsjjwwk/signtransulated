
import React, { ReactNode, useState } from 'react';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

interface FeatureCardProps {
  title: string;
  description: string;
  icon: ReactNode;
  onClick?: () => void;
  className?: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({
  title,
  description,
  icon,
  onClick,
  className,
}) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div 
      className={cn(
        "feature-card cursor-pointer overflow-hidden",
        className
      )}
      onClick={onClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      whileHover={{ y: -5 }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <motion.div 
        className="flex flex-col items-center text-center gap-4 relative z-10"
        initial={{ scale: 1 }}
        animate={{ scale: isHovered ? 1.03 : 1 }}
        transition={{ duration: 0.2 }}
      >
        <motion.div 
          className="bg-primary/10 text-primary p-4 rounded-full relative"
          initial={{ rotate: 0 }}
          animate={{ rotate: isHovered ? 5 : 0 }}
          transition={{ duration: 0.2 }}
        >
          {icon}
          <motion.div
            className="absolute inset-0 rounded-full bg-primary/5"
            initial={{ scale: 1, opacity: 0 }}
            animate={{ 
              scale: isHovered ? [1, 1.2, 1.1] : 1,
              opacity: isHovered ? [0, 0.5, 0] : 0
            }}
            transition={{ 
              duration: 1,
              repeat: isHovered ? Infinity : 0,
              repeatType: "loop"
            }}
          />
        </motion.div>
        
        <h3 className="font-bold text-xl relative">
          {title}
          <motion.div
            className="absolute bottom-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-primary to-transparent"
            initial={{ scaleX: 0, opacity: 0 }}
            animate={{ 
              scaleX: isHovered ? 1 : 0,
              opacity: isHovered ? 1 : 0
            }}
            transition={{ duration: 0.3 }}
          />
        </h3>
        
        <p className="text-muted-foreground">{description}</p>
      </motion.div>
      
      <motion.div
        className="absolute inset-0 bg-gradient-to-br from-primary/5 to-secondary/5 z-0"
        initial={{ opacity: 0 }}
        animate={{ opacity: isHovered ? 1 : 0 }}
        transition={{ duration: 0.3 }}
      />
    </motion.div>
  );
};

export default FeatureCard;
