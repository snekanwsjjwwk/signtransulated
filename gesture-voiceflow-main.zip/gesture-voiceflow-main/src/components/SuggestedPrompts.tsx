
import React from 'react';
import { Button } from '@/components/ui/button';
import { signLanguageFAQs } from '@/data/signLanguageFAQs';
import { ScrollArea } from '@/components/ui/scroll-area';

interface SuggestedPromptsProps {
  onSelectPrompt: (prompt: string) => void;
}

const SuggestedPrompts: React.FC<SuggestedPromptsProps> = ({ onSelectPrompt }) => {
  // Select a random subset of prompts to display
  const getRandomPrompts = (count: number = 5) => {
    const shuffled = [...signLanguageFAQs].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
  };

  const randomPrompts = getRandomPrompts();

  return (
    <div className="w-full">
      <h3 className="text-sm font-medium mb-2 text-muted-foreground">Suggested Questions:</h3>
      <ScrollArea className="h-auto max-h-32">
        <div className="flex flex-wrap gap-2">
          {randomPrompts.map((faq, index) => (
            <Button
              key={index}
              variant="outline"
              size="sm"
              className="text-xs bg-secondary/20 border-secondary/30 hover:bg-secondary/30 text-secondary-foreground whitespace-normal h-auto py-1.5"
              onClick={() => onSelectPrompt(faq.prompt)}
            >
              {faq.prompt}
            </Button>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
};

export default SuggestedPrompts;
