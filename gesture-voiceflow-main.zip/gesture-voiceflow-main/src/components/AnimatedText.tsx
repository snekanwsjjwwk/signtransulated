
import React, { useEffect, useRef, useState } from 'react';

interface AnimatedTextProps {
  text: string;
  className?: string;
  animationType?: 'reveal' | 'wave' | 'float' | 'pulse';
  delay?: number;
  staggerDelay?: number;
  color?: string;
}

const AnimatedText: React.FC<AnimatedTextProps> = ({
  text,
  className = '',
  animationType = 'reveal',
  delay = 0,
  staggerDelay = 0.05,
  color
}) => {
  const [isVisible, setIsVisible] = useState(false);
  const textRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, delay * 1000);

    return () => clearTimeout(timer);
  }, [delay]);

  const getCharStyles = (index: number) => {
    const charDelay = delay + index * staggerDelay;
    
    switch (animationType) {
      case 'reveal':
        return {
          opacity: isVisible ? 1 : 0,
          transform: isVisible ? 'translateY(0)' : 'translateY(20px)',
          transition: `opacity 0.5s ease-out ${charDelay}s, transform 0.5s ease-out ${charDelay}s`
        };
      case 'wave':
        return {
          opacity: isVisible ? 1 : 0,
          animationName: isVisible ? 'wave-effect' : 'none',
          animationDuration: '2s',
          animationDelay: `${charDelay}s`,
          animationIterationCount: 'infinite',
          animationTimingFunction: 'ease-in-out'
        };
      case 'float':
        return {
          opacity: isVisible ? 1 : 0,
          animationName: isVisible ? 'float' : 'none',
          animationDuration: '3s',
          animationDelay: `${charDelay}s`,
          animationIterationCount: 'infinite',
          animationTimingFunction: 'ease-in-out'
        };
      case 'pulse':
        return {
          opacity: isVisible ? 1 : 0,
          animationName: isVisible ? 'pulse-glow' : 'none',
          animationDuration: '2s',
          animationDelay: `${charDelay}s`,
          animationIterationCount: 'infinite',
          animationTimingFunction: 'ease-in-out'
        };
      default:
        return {
          opacity: isVisible ? 1 : 0,
          transition: `opacity 0.5s ease-out ${charDelay}s`
        };
    }
  };

  return (
    <div className={`flex ${className}`} ref={textRef}>
      {text.split('').map((char, index) => (
        <span
          key={index}
          style={{
            ...getCharStyles(index),
            color: color,
            display: 'inline-block'
          }}
          className="inline-block"
        >
          {char === ' ' ? '\u00A0' : char}
        </span>
      ))}
    </div>
  );
};

export default AnimatedText;
