
import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { signLanguageFAQs } from '@/data/signLanguageFAQs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Search, X } from 'lucide-react';

interface FAQViewerProps {
  onSelectFAQ: (prompt: string) => void;
  onClose: () => void;
}

const FAQViewer: React.FC<FAQViewerProps> = ({ onSelectFAQ, onClose }) => {
  const [searchQuery, setSearchQuery] = useState('');
  
  const filteredFAQs = signLanguageFAQs.filter(
    faq => faq.prompt.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <Card className="p-4 w-full glass-card border border-white/10 shadow-xl">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-gradient animate-text-shimmer">Sign Language FAQs</h2>
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X className="h-5 w-5" />
        </Button>
      </div>
      
      <div className="relative mb-4">
        <Input
          placeholder="Search FAQs..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-9 bg-muted/30 border-white/10"
        />
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
      </div>
      
      <ScrollArea className="h-[300px]">
        <div className="space-y-3">
          {filteredFAQs.map((faq, index) => (
            <div 
              key={index} 
              className="p-3 rounded-lg bg-card/50 hover:bg-card/70 cursor-pointer border border-white/5 transition-colors"
              onClick={() => onSelectFAQ(faq.prompt)}
            >
              <p className="font-medium text-sm">{faq.prompt}</p>
              <p className="text-xs text-muted-foreground mt-1">{faq.response.substring(0, 60)}...</p>
            </div>
          ))}
          
          {filteredFAQs.length === 0 && (
            <div className="p-4 text-center text-muted-foreground">
              No FAQs found matching your search.
            </div>
          )}
        </div>
      </ScrollArea>
    </Card>
  );
};

export default FAQViewer;
