
import React, { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  size: number;
  speedX: number;
  speedY: number;
  color: string;
  opacity: number;
  life: number;
  maxLife: number;
}

interface ParticleEffectProps {
  className?: string;
  intensity?: 'low' | 'medium' | 'high';
  colorScheme?: 'primary' | 'secondary' | 'accent' | 'mixed';
}

const ParticleEffect: React.FC<ParticleEffectProps> = ({ 
  className = '',
  intensity = 'medium',
  colorScheme = 'primary'
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const particles = useRef<Particle[]>([]);
  const animationRef = useRef<number>(0);

  const getColors = () => {
    switch (colorScheme) {
      case 'primary':
        return ['#4361ee', '#3a56d4', '#2a4bca'];
      case 'secondary':
        return ['#b02fdd', '#9332c0', '#7834a6'];
      case 'accent':
        return ['#ff9e2a', '#ff8c0a', '#ff7b00'];
      case 'mixed':
        return ['#4361ee', '#b02fdd', '#ff9e2a', '#2a4bca'];
      default:
        return ['#4361ee', '#3a56d4', '#2a4bca'];
    }
  };

  const getParticleCount = () => {
    switch (intensity) {
      case 'low': return 20;
      case 'medium': return 40;
      case 'high': return 80;
      default: return 40;
    }
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const handleResize = () => {
      canvas.width = canvas.clientWidth;
      canvas.height = canvas.clientHeight;
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    const colors = getColors();
    const maxParticles = getParticleCount();

    const createParticle = (): Particle => {
      const size = Math.random() * 4 + 1;
      return {
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size,
        speedX: (Math.random() - 0.5) * 0.5,
        speedY: (Math.random() - 0.5) * 0.5,
        color: colors[Math.floor(Math.random() * colors.length)],
        opacity: Math.random() * 0.5 + 0.1,
        life: 0,
        maxLife: Math.random() * 200 + 50
      };
    };

    // Initialize particles
    for (let i = 0; i < maxParticles; i++) {
      particles.current.push(createParticle());
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Update and draw particles
      particles.current.forEach((particle, index) => {
        particle.x += particle.speedX;
        particle.y += particle.speedY;
        particle.life++;
        
        // Particle fading based on life
        const fadeRatio = 1 - particle.life / particle.maxLife;
        const currentOpacity = particle.opacity * fadeRatio;
        
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fillStyle = `${particle.color}${Math.floor(currentOpacity * 255).toString(16).padStart(2, '0')}`;
        ctx.fill();
        
        // Respawn particles
        if (particle.life >= particle.maxLife) {
          particles.current[index] = createParticle();
        }
        
        // Bounce off edges
        if (particle.x < 0 || particle.x > canvas.width) {
          particle.speedX *= -1;
        }
        
        if (particle.y < 0 || particle.y > canvas.height) {
          particle.speedY *= -1;
        }
      });
      
      animationRef.current = requestAnimationFrame(animate);
    };
    
    animate();
    
    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationRef.current);
    };
  }, [intensity, colorScheme]);
  
  return (
    <canvas 
      ref={canvasRef} 
      className={`absolute inset-0 w-full h-full -z-10 ${className}`}
    />
  );
};

export default ParticleEffect;
