
import React from 'react';

interface HandIconProps {
  className?: string;
  animate?: boolean;
}

const HandIcon: React.FC<HandIconProps> = ({ className = '', animate = false }) => {
  return (
    <svg 
      className={`${className} ${animate ? 'animate-hand-wave' : ''}`} 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
    >
      <path 
        d="M6.5 12.5C6.5 11.3954 7.39543 10.5 8.5 10.5C9.60457 10.5 10.5 11.3954 10.5 12.5V17C10.5 17.8284 11.1716 18.5 12 18.5C12.8284 18.5 13.5 17.8284 13.5 17V7.5C13.5 6.39543 14.3954 5.5 15.5 5.5C16.6046 5.5 17.5 6.39543 17.5 7.5V17C17.5 19.4853 15.4853 21.5 13 21.5H11C8.51472 21.5 6.5 19.4853 6.5 17V12.5Z" 
        stroke="currentColor" 
        strokeWidth="1.5" 
        strokeLinecap="round" 
        strokeLinejoin="round"
      />
      <path 
        d="M13.5 7.5V5.5" 
        stroke="currentColor" 
        strokeWidth="1.5" 
        strokeLinecap="round" 
        strokeLinejoin="round"
      />
      <path 
        d="M10.5 12.5V11C10.5 9.89543 11.3954 9 12.5 9C13.6046 9 14.5 9.89543 14.5 11V12" 
        stroke="currentColor" 
        strokeWidth="1.5" 
        strokeLinecap="round" 
        strokeLinejoin="round"
      />
    </svg>
  );
};

export default HandIcon;
