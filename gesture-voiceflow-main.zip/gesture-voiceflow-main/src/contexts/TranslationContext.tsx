
import React, { createContext, useContext, useState, ReactNode } from 'react';

interface TranslationContextType {
  isTranslating: boolean;
  translatedText: string;
  currentGesture: string | null;
  startTranslation: () => void;
  stopTranslation: () => void;
  setTranslatedText: (text: string) => void;
  setCurrentGesture: (gesture: string | null) => void;
}

const TranslationContext = createContext<TranslationContextType | undefined>(undefined);

export const TranslationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isTranslating, setIsTranslating] = useState(false);
  const [translatedText, setTranslatedText] = useState('');
  const [currentGesture, setCurrentGesture] = useState<string | null>(null);

  const startTranslation = () => {
    setIsTranslating(true);
    setTranslatedText('');
  };

  const stopTranslation = () => {
    setIsTranslating(false);
  };

  return (
    <TranslationContext.Provider 
      value={{ 
        isTranslating, 
        translatedText, 
        currentGesture,
        startTranslation, 
        stopTranslation, 
        setTranslatedText,
        setCurrentGesture
      }}
    >
      {children}
    </TranslationContext.Provider>
  );
};

export const useTranslation = () => {
  const context = useContext(TranslationContext);
  if (context === undefined) {
    throw new Error('useTranslation must be used within a TranslationProvider');
  }
  return context;
};
