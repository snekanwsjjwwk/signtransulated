
export interface SignLanguageFAQ {
  prompt: string;
  response: string;
}

export const signLanguageFAQs: SignLanguageFAQ[] = [
  {
    prompt: "What is sign language?",
    response: "Sign language is a visual language that uses hand gestures, facial expressions, and body movements to communicate. It is commonly used by the deaf and hard-of-hearing communities."
  },
  {
    prompt: "How many types of sign languages exist?",
    response: "There are over 300 different sign languages worldwide, including American Sign Language (ASL), British Sign Language (BSL), and French Sign Language (LSF). Each has its own grammar and vocabulary."
  },
  {
    prompt: "How can I learn sign language quickly?",
    response: "To learn sign language quickly, practice daily, watch sign language videos, use sign language apps, and engage with deaf communities. Consistency and real-world practice help improve fluency."
  },
  {
    prompt: "What is fingerspelling in ASL?",
    response: "Fingerspelling in ASL is the use of hand signs to spell out words, typically for names, places, or words without established signs."
  },
  {
    prompt: "Can AI recognize sign language?",
    response: "Yes, AI can recognize sign language using computer vision models like MediaPipe Hands and YOLO. These models track hand movements and translate gestures into text or speech."
  },
  {
    prompt: "How does sign language differ from spoken language?",
    response: "Sign languages have their own grammar and structure, different from spoken languages. They rely on hand shapes, movements, and facial expressions rather than sounds."
  },
  {
    prompt: "What are classifiers in ASL?",
    response: "Classifiers in ASL are handshapes that represent objects, people, or movements. They help describe actions and provide more context in conversations."
  },
  {
    prompt: "What is the best AI model for sign language recognition?",
    response: "Models like MediaPipe Hands, YOLOv5, and DeepSeek AI are commonly used for sign language recognition. They analyze hand shapes and movements in real time."
  },
  {
    prompt: "What is the difference between ASL and BSL?",
    response: "American Sign Language (ASL) uses a one-handed fingerspelling system, while British Sign Language (BSL) uses a two-handed system. Their grammar and signs are also different."
  },
  {
    prompt: "How can AI improve accessibility for the deaf?",
    response: "AI can provide real-time sign language translation, convert speech to sign, and enable better communication through sign language recognition apps."
  },
  {
    prompt: "What is a common greeting in sign language?",
    response: "A common greeting in ASL is waving your hand or signing 'Hello' by moving an open hand from your forehead outward."
  },
  {
    prompt: "How do you sign 'Thank You' in ASL?",
    response: "To sign 'Thank You' in ASL, place your fingertips on your chin and move your hand outward."
  },
  {
    prompt: "Can AI translate sign language in real-time?",
    response: "Yes, AI-powered models can translate sign language in real-time using hand tracking and gesture recognition algorithms."
  },
  {
    prompt: "What is the TTY device for deaf communication?",
    response: "A TTY (Text Telephone) is a device that allows deaf individuals to communicate over the phone by typing messages instead of speaking."
  },
  {
    prompt: "How do facial expressions affect sign language?",
    response: "Facial expressions play a crucial role in sign language, as they convey emotions and grammatical nuances that modify the meaning of signs."
  },
  {
    prompt: "What is the role of hand dominance in sign language?",
    response: "Hand dominance determines which hand is used for signing. In ASL, the dominant hand performs movements, while the non-dominant hand remains stationary for support."
  },
  {
    prompt: "What tools can help recognize sign language gestures?",
    response: "AI tools like MediaPipe Hands, OpenPose, and TensorFlow can track hand movements and translate sign language gestures into text or speech."
  },
  {
    prompt: "What is the best way to practice sign language?",
    response: "Practice by watching sign language videos, joining deaf community events, using interactive apps, and signing with friends regularly."
  },
  {
    prompt: "How do you say 'I love you' in ASL?",
    response: "To sign 'I love you' in ASL, extend your thumb, index finger, and pinky finger while keeping the middle and ring fingers down."
  }
];
