
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Hand, MessageSquareText, LogOut } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import Logo from '@/components/Logo';
import FeatureCard from '@/components/FeatureCard';
import ParticleEffect from '@/components/ParticleEffect';
import AnimatedText from '@/components/AnimatedText';

const HomePage: React.FC = () => {
  const { toast } = useToast();
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    toast({
      title: 'Logged out',
      description: 'You have been successfully logged out.',
    });
    navigate('/');
  };

  const navigateToTranslation = () => {
    navigate('/translation');
  };

  const navigateToChatbot = () => {
    navigate('/chatbot');
  };

  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden bg-gradient-to-br from-background via-background to-background/90">
      <ParticleEffect intensity="low" colorScheme="mixed" />
      
      <header className="bg-card/30 backdrop-blur-xl border-b border-white/10 py-4 px-6 relative z-10">
        <div className="container mx-auto flex justify-between items-center">
          <Logo className="animate-float" />
          <div className="flex items-center gap-4">
            <span className="text-sm font-medium text-foreground/90">Hi, {user?.name || 'User'}</span>
            <Button variant="ghost" size="icon" onClick={handleLogout} className="hover:bg-white/10 transition-colors">
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto py-12 px-6 relative z-10">
        <div className="text-center mb-16">
          <div className="inline-block mb-4">
            <AnimatedText 
              text="Choose Your Experience" 
              className="text-4xl font-bold text-gradient" 
              animationType="float"
            />
          </div>
          <p className="text-muted-foreground max-w-lg mx-auto opacity-80">
            Select one of our features to get started. Each offers a unique way to bridge communication barriers through technology.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-4xl mx-auto">
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-primary to-secondary rounded-2xl blur-lg opacity-30 group-hover:opacity-80 transition-all duration-500"></div>
            <FeatureCard
              title="Live Sign Language Translation"
              description="Translate sign language to text and speech in real-time using your camera"
              icon={<Hand className="h-8 w-8 animate-pulse-glow" />}
              onClick={navigateToTranslation}
              className="glass-card relative z-10 group-hover:border-primary/50 transition-all duration-300"
            />
          </div>
          
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-secondary to-accent rounded-2xl blur-lg opacity-30 group-hover:opacity-80 transition-all duration-500"></div>
            <FeatureCard
              title="Sign Language Chatbot"
              description="Chat with our AI assistant using sign language for seamless communication"
              icon={<MessageSquareText className="h-8 w-8 animate-pulse-glow" />}
              onClick={navigateToChatbot}
              className="glass-card relative z-10 group-hover:border-secondary/50 transition-all duration-300"
            />
          </div>
        </div>

        <div className="mt-20 text-center">
          <AnimatedText 
            text="Break the silence, Bridge the gap" 
            className="text-xl font-light tracking-wide opacity-70" 
            animationType="reveal"
            delay={1}
          />
        </div>
      </main>

      <footer className="py-6 border-t border-white/10 relative z-10 backdrop-blur-sm">
        <div className="container mx-auto text-center text-sm text-muted-foreground">
          &copy; {new Date().getFullYear()} GestureVoice. All rights reserved.
        </div>
      </footer>
    </div>
  );
};

export default HomePage;
