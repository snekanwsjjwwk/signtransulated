
import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useTranslation } from '@/contexts/TranslationContext';
import { ArrowLeft, Mic, Video, VideoOff, Volume2 } from 'lucide-react';
import HandIcon from '@/components/HandIcon';
import ParticleEffect from '@/components/ParticleEffect';
import AnimatedText from '@/components/AnimatedText';
import { motion, AnimatePresence } from 'framer-motion';

const TranslationPage: React.FC = () => {
  const { toast } = useToast();
  const { 
    isTranslating, 
    translatedText, 
    currentGesture, 
    startTranslation, 
    stopTranslation, 
    setTranslatedText,
    setCurrentGesture
  } = useTranslation();
  const navigate = useNavigate();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [translationProgress, setTranslationProgress] = useState(0);
  const [showTips, setShowTips] = useState(false);

  // This effect simulates the translation process
  useEffect(() => {
    if (!isTranslating) return;

    const gestureLibrary = [
      'Hello', 'Thank you', 'Yes', 'No', 'Help',
      'Please', 'Sorry', 'Good', 'Bad', 'Love'
    ];
    
    let sentence = '';
    let index = 0;
    
    const interval = setInterval(() => {
      if (index < gestureLibrary.length) {
        // Simulate detecting a gesture
        const gesture = gestureLibrary[index];
        setCurrentGesture(gesture);
        
        // Add to the translated text after a delay
        setTimeout(() => {
          sentence += (sentence ? ' ' : '') + gesture;
          setTranslatedText(sentence);
          setCurrentGesture(null);
        }, 1000);
        
        index++;
        setTranslationProgress(Math.min((index / gestureLibrary.length) * 100, 100));
      } else {
        clearInterval(interval);
        stopTranslation();
        toast({
          title: 'Translation complete',
          description: 'Sign language translation has been completed.',
        });
      }
    }, 2000);
    
    return () => clearInterval(interval);
  }, [isTranslating]);

  const handleStartCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'user',
          width: { ideal: 640 },
          height: { ideal: 480 } 
        } 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setCameraActive(true);
        toast({
          title: 'Camera activated',
          description: 'Ready to begin translation.',
        });
      }
    } catch (error) {
      console.error('Error accessing camera:', error);
      toast({
        title: 'Camera access error',
        description: 'Unable to access your camera. Please check permissions.',
        variant: 'destructive',
      });
    }
  };

  const handleStopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
      setCameraActive(false);
      
      if (isTranslating) {
        stopTranslation();
      }
    }
  };

  const handleStartTranslation = () => {
    if (!cameraActive) {
      toast({
        title: 'Camera required',
        description: 'Please activate your camera first.',
        variant: 'destructive',
      });
      return;
    }
    
    startTranslation();
    setTranslationProgress(0);
    toast({
      title: 'Translation started',
      description: 'Observing sign language gestures...',
    });
  };

  const handleStopTranslation = () => {
    stopTranslation();
    toast({
      title: 'Translation stopped',
      description: 'Sign language translation has been stopped.',
    });
  };

  const handlePlaySpeech = () => {
    if (!translatedText) return;
    
    // In a real app, this would use the Web Speech API or a TTS service
    const speech = new SpeechSynthesisUtterance(translatedText);
    window.speechSynthesis.speak(speech);
    
    toast({
      title: 'Playing speech',
      description: 'Text-to-speech output is playing.',
    });
  };

  const handleGoBack = () => {
    if (cameraActive) {
      handleStopCamera();
    }
    navigate('/home');
  };

  const toggleTips = () => {
    setShowTips(!showTips);
  };

  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden bg-gradient-to-br from-background to-background/90">
      <ParticleEffect intensity="low" colorScheme="primary" />
      
      <header className="bg-card/30 backdrop-blur-xl border-b border-white/10 py-4 px-6 relative z-10">
        <div className="container mx-auto flex items-center">
          <Button variant="ghost" size="icon" onClick={handleGoBack} className="mr-4 hover:bg-white/10">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <motion.h1 
            className="text-xl font-bold"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Live Sign Language Translation
          </motion.h1>
        </div>
      </header>

      <main className="flex-1 container mx-auto py-8 px-6 relative z-10">
        <motion.div 
          className="grid grid-cols-1 lg:grid-cols-2 gap-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <div className="flex flex-col space-y-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              <Card className="relative overflow-hidden bg-black/80 aspect-video flex items-center justify-center border border-white/10 rounded-xl shadow-xl">
                {!cameraActive && !isTranslating && (
                  <motion.div 
                    className="text-center text-white"
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ duration: 0.5, delay: 0.3 }}
                  >
                    <HandIcon className="h-16 w-16 mx-auto mb-4 text-primary animate-pulse-glow" />
                    <p>Camera is off. Activate to begin translation.</p>
                  </motion.div>
                )}
                <video 
                  ref={videoRef} 
                  autoPlay 
                  playsInline 
                  muted 
                  className={`w-full h-full object-cover ${!cameraActive ? 'hidden' : ''}`}
                />
                <canvas 
                  ref={canvasRef} 
                  className="absolute inset-0 w-full h-full" 
                />
                
                <AnimatePresence>
                  {currentGesture && (
                    <motion.div 
                      className="absolute top-4 right-4 bg-primary text-primary-foreground px-4 py-2 rounded-full text-sm font-medium"
                      initial={{ opacity: 0, y: -20, scale: 0.8 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.8 }}
                      transition={{ duration: 0.3 }}
                    >
                      Detected: {currentGesture}
                    </motion.div>
                  )}
                </AnimatePresence>
                
                {isTranslating && (
                  <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-gray-700/50">
                    <motion.div 
                      className="h-full bg-gradient-to-r from-primary via-secondary to-primary"
                      initial={{ width: '0%' }}
                      animate={{ width: `${translationProgress}%` }}
                      transition={{ duration: 0.5 }}
                    />
                  </div>
                )}
              </Card>
            </motion.div>
            
            <div className="flex flex-wrap gap-4">
              {!cameraActive ? (
                <motion.div 
                  className="flex-1"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Button 
                    onClick={handleStartCamera} 
                    className="w-full sign-btn sign-btn-primary"
                  >
                    <Video className="h-5 w-5 mr-2" />
                    Activate Camera
                  </Button>
                </motion.div>
              ) : (
                <motion.div 
                  className="flex-1"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Button 
                    onClick={handleStopCamera} 
                    className="w-full sign-btn" 
                    variant="outline"
                  >
                    <VideoOff className="h-5 w-5 mr-2" />
                    Deactivate Camera
                  </Button>
                </motion.div>
              )}
              
              {!isTranslating ? (
                <motion.div 
                  className="flex-1"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Button 
                    onClick={handleStartTranslation} 
                    className="w-full sign-btn sign-btn-primary"
                    disabled={!cameraActive}
                  >
                    <Mic className="h-5 w-5 mr-2" />
                    Start Translating
                  </Button>
                </motion.div>
              ) : (
                <motion.div 
                  className="flex-1"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Button 
                    onClick={handleStopTranslation} 
                    className="w-full sign-btn" 
                    variant="secondary"
                  >
                    <Mic className="h-5 w-5 mr-2" />
                    Stop Translating
                  </Button>
                </motion.div>
              )}
            </div>
          </div>
          
          <div className="flex flex-col space-y-4">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Card className="p-6 flex-1 flex flex-col bg-card/50 backdrop-blur-lg border border-white/10 shadow-lg">
                <motion.h2 
                  className="text-xl font-bold mb-4 text-gradient"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.5, delay: 0.4 }}
                >
                  Translation Output
                </motion.h2>
                
                <motion.div 
                  className="flex-1 border border-white/10 rounded-md p-4 mb-4 min-h-[200px] bg-muted/10 backdrop-blur"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.5 }}
                >
                  {translatedText ? (
                    <AnimatedText 
                      text={translatedText} 
                      className="text-lg" 
                      animationType="wave"
                      delay={0.2}
                    />
                  ) : (
                    <p className="text-muted-foreground">
                      {isTranslating 
                        ? 'Waiting for signs to translate...' 
                        : 'Translation output will appear here.'
                      }
                    </p>
                  )}
                </motion.div>
                
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Button 
                    onClick={handlePlaySpeech} 
                    className="w-full sign-btn" 
                    variant="outline"
                    disabled={!translatedText}
                  >
                    <Volume2 className="h-5 w-5 mr-2" />
                    Play as Speech
                  </Button>
                </motion.div>
              </Card>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <Card className="p-6 bg-card/50 backdrop-blur-lg border border-white/10 shadow-lg overflow-hidden">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-lg font-semibold">Tips for Better Translation</h3>
                  <Button variant="ghost" size="sm" onClick={toggleTips} className="text-xs">
                    {showTips ? 'Hide' : 'Show more'}
                  </Button>
                </div>
                
                <AnimatePresence>
                  <motion.ul 
                    className="space-y-2 text-sm text-muted-foreground"
                    initial={{ height: 'auto' }}
                    animate={{ height: 'auto' }}
                    exit={{ height: 'auto' }}
                  >
                    <motion.li 
                      className="flex items-start"
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.3, delay: 0.1 }}
                    >
                      <span className="bg-primary/10 text-primary rounded-full p-1 mr-2 mt-0.5">1</span>
                      Ensure good lighting for optimal hand tracking
                    </motion.li>
                    <motion.li 
                      className="flex items-start"
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.3, delay: 0.2 }}
                    >
                      <span className="bg-primary/10 text-primary rounded-full p-1 mr-2 mt-0.5">2</span>
                      Position your hands within the camera frame
                    </motion.li>
                    
                    {showTips && (
                      <>
                        <motion.li 
                          className="flex items-start"
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.3, delay: 0.3 }}
                        >
                          <span className="bg-primary/10 text-primary rounded-full p-1 mr-2 mt-0.5">3</span>
                          Make clear, deliberate gestures for better recognition
                        </motion.li>
                        <motion.li 
                          className="flex items-start"
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.3, delay: 0.4 }}
                        >
                          <span className="bg-primary/10 text-primary rounded-full p-1 mr-2 mt-0.5">4</span>
                          Maintain a neutral background to reduce interference
                        </motion.li>
                        <motion.li 
                          className="flex items-start"
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.3, delay: 0.5 }}
                        >
                          <span className="bg-primary/10 text-primary rounded-full p-1 mr-2 mt-0.5">5</span>
                          Keep a consistent distance from the camera
                        </motion.li>
                      </>
                    )}
                  </motion.ul>
                </AnimatePresence>
              </Card>
            </motion.div>
          </div>
        </motion.div>
      </main>
    </div>
  );
};

export default TranslationPage;
