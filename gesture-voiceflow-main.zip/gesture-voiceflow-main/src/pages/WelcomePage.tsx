
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import Logo from '@/components/Logo';

const WelcomePage: React.FC = () => {
  const [mode, setMode] = useState<'welcome' | 'login' | 'signup'>('welcome');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const { toast } = useToast();
  const { login, signup, isLoading } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await login(email, password);
      toast({
        title: 'Login successful',
        description: 'Welcome back to GestureVoice!',
      });
      navigate('/home');
    } catch (error) {
      toast({
        title: 'Login failed',
        description: 'Please check your credentials and try again.',
        variant: 'destructive',
      });
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await signup(email, password, name);
      toast({
        title: 'Account created',
        description: 'Welcome to GestureVoice!',
      });
      navigate('/home');
    } catch (error) {
      toast({
        title: 'Signup failed',
        description: 'Please check your information and try again.',
        variant: 'destructive',
      });
    }
  };

  const renderWelcome = () => (
    <div className="flex flex-col items-center space-y-8 px-4">
      <div className="animate-fade-in space-y-4 text-center">
        <Logo size="lg" />
        <h1 className="text-4xl font-bold tracking-tight">Welcome to GestureVoice</h1>
        <p className="text-xl text-muted-foreground">
          Breaking barriers through sign language translation
        </p>
      </div>
      
      <div className="flex flex-col space-y-4 w-full max-w-md">
        <Button 
          onClick={() => setMode('signup')} 
          className="sign-btn sign-btn-primary"
          size="lg"
        >
          Get Started
        </Button>
        <Button 
          onClick={() => setMode('login')} 
          className="sign-btn sign-btn-outline"
          variant="outline"
          size="lg"
        >
          I already have an account
        </Button>
      </div>
    </div>
  );

  const renderLogin = () => (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <div className="flex justify-center mb-4">
          <Logo />
        </div>
        <CardTitle className="text-2xl text-center">Welcome back</CardTitle>
        <CardDescription className="text-center">
          Enter your email and password to log in to your account
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleLogin}>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input 
              id="email" 
              type="email" 
              placeholder="youremail@example.com" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input 
              id="password" 
              type="password" 
              placeholder="••••••••" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          <Button 
            type="submit" 
            className="w-full sign-btn sign-btn-primary"
            disabled={isLoading}
          >
            {isLoading ? 'Logging in...' : 'Log in'}
          </Button>
          <Button
            type="button"
            variant="link"
            onClick={() => setMode('signup')}
            className="text-sm"
          >
            Don't have an account? Sign up
          </Button>
          <Button
            type="button"
            variant="link"
            onClick={() => setMode('welcome')}
            className="text-sm"
          >
            Back to welcome
          </Button>
        </CardFooter>
      </form>
    </Card>
  );

  const renderSignup = () => (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <div className="flex justify-center mb-4">
          <Logo />
        </div>
        <CardTitle className="text-2xl text-center">Create an account</CardTitle>
        <CardDescription className="text-center">
          Enter your information to create a new account
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleSignup}>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Name</Label>
            <Input 
              id="name" 
              type="text" 
              placeholder="Your name" 
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="signup-email">Email</Label>
            <Input 
              id="signup-email" 
              type="email" 
              placeholder="youremail@example.com" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="signup-password">Password</Label>
            <Input 
              id="signup-password" 
              type="password" 
              placeholder="Create a password" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          <Button 
            type="submit" 
            className="w-full sign-btn sign-btn-primary"
            disabled={isLoading}
          >
            {isLoading ? 'Creating account...' : 'Create account'}
          </Button>
          <Button
            type="button"
            variant="link"
            onClick={() => setMode('login')}
            className="text-sm"
          >
            Already have an account? Log in
          </Button>
          <Button
            type="button"
            variant="link"
            onClick={() => setMode('welcome')}
            className="text-sm"
          >
            Back to welcome
          </Button>
        </CardFooter>
      </form>
    </Card>
  );

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6">
      {mode === 'welcome' && renderWelcome()}
      {mode === 'login' && renderLogin()}
      {mode === 'signup' && renderSignup()}
    </div>
  );
};

export default WelcomePage;
