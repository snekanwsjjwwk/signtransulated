import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { 
  ArrowLeft, 
  HandMetal, 
  MessageSquare, 
  Send, 
  Video, 
  VideoOff, 
  BookOpen,
  Lightbulb,
  Info,
  RefreshCw
} from 'lucide-react';
import HandIcon from '@/components/HandIcon';
import { useTranslation } from '@/contexts/TranslationContext';
import { cn } from '@/lib/utils';
import { signLanguageFAQs } from '@/data/signLanguageFAQs';
import SuggestedPrompts from '@/components/SuggestedPrompts';
import FAQViewer from '@/components/FAQViewer';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';

interface Message {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: Date;
}

const ChatbotPage: React.FC = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const { startTranslation, stopTranslation } = useTranslation();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      sender: 'bot',
      text: 'Hello! I\'m your sign language assistant. You can type a message, use sign language, or select from common sign language questions below.',
      timestamp: new Date(),
    },
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [cameraActive, setCameraActive] = useState(false);
  const [isProcessingGesture, setIsProcessingGesture] = useState(false);
  const [apiKey] = useState('sk-28fe33506d2b4881b9da743aa5a23017');
  const [isCapturing, setIsCapturing] = useState(false);
  const captureIntervalRef = useRef<number | null>(null);
  const [showFAQ, setShowFAQ] = useState(false);
  const [captureInterval, setCaptureInterval] = useState<number>(5000);
  const [captureMode, setCaptureMode] = useState<'continuous' | 'manual'>('continuous');

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    return () => {
      if (captureIntervalRef.current) {
        window.clearInterval(captureIntervalRef.current);
      }
      handleStopCamera();
    };
  }, []);

  useEffect(() => {
    if (isCapturing && captureMode === 'continuous') {
      stopContinuousCapture();
      startContinuousCapture();
    }
  }, [captureInterval]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleStartCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'user',
          width: { ideal: 640 },
          height: { ideal: 480 } 
        } 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setCameraActive(true);
        toast({
          title: 'Camera activated',
          description: 'Ready to capture sign language.',
        });
      }
    } catch (error) {
      console.error('Error accessing camera:', error);
      toast({
        title: 'Camera access error',
        description: 'Unable to access your camera. Please check permissions.',
        variant: 'destructive',
      });
    }
  };

  const handleStopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
      setCameraActive(false);
    }
    
    if (isCapturing) {
      stopContinuousCapture();
    }
  };

  const captureFrame = async () => {
    if (!cameraActive || !videoRef.current || !canvasRef.current) return null;
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');
    
    if (!context) return null;
    
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    try {
      const blob = await new Promise<Blob>((resolve) => {
        canvas.toBlob((blob) => {
          if (blob) resolve(blob);
          else throw new Error("Failed to create blob from canvas");
        }, 'image/jpeg', 0.9);
      });
      
      return blob;
    } catch (error) {
      console.error('Error capturing frame:', error);
      return null;
    }
  };

  const processGestureWithDeepSeek = async (imageBlob: Blob) => {
    try {
      const formData = new FormData();
      formData.append('image', imageBlob, 'sign_image.jpg');
      
      const response = await fetch('https://api.deepseek.com/v1/sign-language/analyze', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
        },
        body: formData,
      });
      
      if (!response.ok) {
        const errorData = await response.text();
        console.error('API Error:', errorData);
        throw new Error(`API request failed with status ${response.status}: ${errorData}`);
      }
      
      const data = await response.json();
      console.log('DeepSeek API response:', data);
      return data.text || "I couldn't recognize that sign. Please try again.";
    } catch (error) {
      console.error('Error processing sign language:', error);
      return "Error processing sign language. Please try again.";
    }
  };

  const handleCaptureGesture = async () => {
    if (!cameraActive) {
      toast({
        title: 'Camera required',
        description: 'Please activate your camera first.',
        variant: 'destructive',
      });
      return;
    }
    
    setIsProcessingGesture(true);
    
    try {
      const imageBlob = await captureFrame();
      
      if (!imageBlob) {
        throw new Error('Failed to capture frame');
      }

      toast({
        title: 'Processing',
        description: 'Analyzing sign language...',
      });
      
      let recognizedText = await processGestureWithDeepSeek(imageBlob);
      
      const userMessage: Message = {
        id: Date.now().toString(),
        sender: 'user',
        text: recognizedText,
        timestamp: new Date(),
      };
      
      setMessages(prev => [...prev, userMessage]);
      
      const botResponse = await generateBotResponse(recognizedText);
      
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'bot',
        text: botResponse,
        timestamp: new Date(),
      };
      
      setMessages(prev => [...prev, botMessage]);
      setIsProcessingGesture(false);
      
    } catch (error) {
      console.error('Error capturing gesture:', error);
      toast({
        title: 'Capture failed',
        description: 'Failed to process sign language. Please try again.',
        variant: 'destructive',
      });
      setIsProcessingGesture(false);
    }
  };

  const generateBotResponse = async (userMessage: string) => {
    const normalizedMsg = userMessage.toLowerCase();
    const matchingFAQ = signLanguageFAQs.find(faq => 
      faq.prompt.toLowerCase().includes(normalizedMsg) || 
      normalizedMsg.includes(faq.prompt.toLowerCase())
    );
    
    if (matchingFAQ) {
      return matchingFAQ.response;
    }
    
    if (normalizedMsg.includes('hello') || normalizedMsg.includes('hi')) {
      return "Hello! How can I assist you today?";
    } else if (normalizedMsg.includes('how are you')) {
      return "I'm doing well, thank you for asking! How can I help you?";
    } else if (normalizedMsg.includes('thank')) {
      return "You're welcome! Is there anything else I can help with?";
    } else if (normalizedMsg.includes('help')) {
      return "I'm here to help! I can understand sign language and respond to your queries. What do you need assistance with?";
    } else if (normalizedMsg.includes('bye') || normalizedMsg.includes('goodbye')) {
      return "Goodbye! Feel free to come back anytime you need assistance.";
    } else if (normalizedMsg.includes('sign language') || normalizedMsg.includes('asl')) {
      return "Sign language is a visual form of communication that uses hand gestures, facial expressions, and body movements. Would you like to know more about a specific aspect of sign language?";
    } else if (normalizedMsg.includes('learn')) {
      return "To learn sign language, I'd recommend starting with basic vocabulary, watching tutorials, practicing with others, and using apps dedicated to sign language learning. Would you like some specific resources?";
    } else {
      return `I understand you're saying: "${userMessage}". Is there something specific about sign language you'd like to know?`;
    }
  };

  const startContinuousCapture = () => {
    if (!cameraActive) {
      handleStartCamera().then(() => {
        setIsCapturing(true);
        startTranslation();
        captureIntervalRef.current = window.setInterval(handleCaptureGesture, captureInterval);
        
        toast({
          title: 'Continuous capture started',
          description: `Capturing sign language every ${captureInterval/1000} seconds`,
        });
      });
    } else {
      setIsCapturing(true);
      startTranslation();
      captureIntervalRef.current = window.setInterval(handleCaptureGesture, captureInterval);
      
      toast({
        title: 'Continuous capture started',
        description: `Capturing sign language every ${captureInterval/1000} seconds`,
      });
    }
  };

  const stopContinuousCapture = () => {
    if (captureIntervalRef.current) {
      window.clearInterval(captureIntervalRef.current);
      captureIntervalRef.current = null;
    }
    setIsCapturing(false);
    stopTranslation();
    
    toast({
      title: 'Capture stopped',
      description: 'Sign language recognition paused',
    });
  };

  const toggleCaptureMode = () => {
    if (isCapturing) {
      stopContinuousCapture();
    } else {
      if (captureMode === 'continuous') {
        startContinuousCapture();
      } else {
        handleCaptureGesture();
      }
    }
  };

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return;
    
    const userMessage: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text: inputMessage,
      timestamp: new Date(),
    };
    
    setMessages(prev => [...prev, userMessage]);
    
    generateBotResponse(inputMessage).then(response => {
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'bot',
        text: response,
        timestamp: new Date(),
      };
      
      setMessages(prev => [...prev, botMessage]);
    });
    
    setInputMessage('');
  };

  const handleGoBack = () => {
    if (cameraActive) {
      handleStopCamera();
    }
    navigate('/home');
  };

  const handleSelectFAQ = (question: string) => {
    setInputMessage(question);
    setShowFAQ(false);
  };

  const handleSelectPrompt = (prompt: string) => {
    setInputMessage(prompt);
    setTimeout(() => {
      const userMessage: Message = {
        id: Date.now().toString(),
        sender: 'user',
        text: prompt,
        timestamp: new Date(),
      };
      
      setMessages(prev => [...prev, userMessage]);
      
      const matchingFAQ = signLanguageFAQs.find(faq => faq.prompt === prompt);
      
      if (matchingFAQ) {
        const botMessage: Message = {
          id: (Date.now() + 1).toString(),
          sender: 'bot',
          text: matchingFAQ.response,
          timestamp: new Date(),
        };
        
        setMessages(prev => [...prev, botMessage]);
      }
      
      setInputMessage('');
    }, 100);
  };

  const toggleFAQView = () => {
    setShowFAQ(!showFAQ);
  };

  const handleRefreshPrompts = () => {
    setShowFAQ(false);
    setTimeout(() => {
      setShowFAQ(true);
    }, 50);
  };

  const setCaptureSpeed = (speed: 'slow' | 'medium' | 'fast') => {
    switch (speed) {
      case 'slow':
        setCaptureInterval(8000);
        break;
      case 'medium':
        setCaptureInterval(5000);
        break;
      case 'fast':
        setCaptureInterval(3000);
        break;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-background via-background/80 to-card/30 backdrop-blur-sm">
      <header className="bg-card/50 backdrop-blur-md border-b border-white/10 py-4 px-6">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center">
            <Button variant="ghost" size="icon" onClick={handleGoBack} className="mr-4">
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-bold text-gradient animate-text-shimmer">Sign Language Chatbot</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="sm" 
              className="flex items-center gap-1 text-xs"
              onClick={toggleFAQView}
            >
              <BookOpen className="h-4 w-4" />
              {showFAQ ? 'Hide FAQs' : 'Show FAQs'}
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto py-8 px-6 flex flex-col">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 flex-1">
          <div className="lg:col-span-2">
            <Card className="flex flex-col h-full glass-card overflow-hidden border border-white/10 bg-gradient-to-b from-background/30 to-card/30">
              <div className="p-4 border-b border-white/10 bg-gradient-to-r from-primary/10 to-secondary/10">
                <h2 className="font-semibold flex items-center gap-2">
                  <MessageSquare className="h-5 w-5 text-primary animate-pulse-glow" />
                  Conversation
                </h2>
              </div>
              
              <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-black/10">
                {messages.map(message => (
                  <div 
                    key={message.id}
                    className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div 
                      className={cn(
                        `max-w-[80%] rounded-lg p-3 backdrop-blur-md`, 
                        message.sender === 'user' 
                          ? 'bg-primary/80 text-primary-foreground shadow-lg shadow-primary/30' 
                          : 'bg-secondary/30 text-foreground border border-white/5 shadow-lg shadow-secondary/10'
                      )}
                    >
                      <p>{message.text}</p>
                      <p className="text-xs opacity-70 mt-1">
                        {message.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                      </p>
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
              
              <div className="p-4 border-t border-white/10 bg-gradient-to-r from-primary/5 to-secondary/5">
                <div className="space-y-4">
                  {!showFAQ && (
                    <SuggestedPrompts onSelectPrompt={handleSelectPrompt} />
                  )}
                  
                  <div className="flex gap-2">
                    <Input
                      placeholder="Type your message..."
                      value={inputMessage}
                      onChange={(e) => setInputMessage(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                      className="bg-muted/30 border-white/10 focus:border-primary/50 focus:ring-1 focus:ring-primary/50"
                    />
                    <Button 
                      onClick={handleSendMessage}
                      className="bg-primary hover:bg-primary/80 text-white shadow-md shadow-primary/30 transition-all"
                    >
                      <Send className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </div>
          
          <div className="flex flex-col gap-4">
            {showFAQ ? (
              <FAQViewer 
                onSelectFAQ={handleSelectPrompt}
                onClose={() => setShowFAQ(false)}
              />
            ) : (
              <>
                <Card className="overflow-hidden bg-black/70 aspect-video flex items-center justify-center relative glass-card border border-white/10">
                  {!cameraActive && (
                    <div className="text-center text-white">
                      <HandIcon className="h-16 w-16 mx-auto mb-4 text-primary animate-pulse-glow" />
                      <p>Camera is off. Activate to use sign language.</p>
                    </div>
                  )}
                  <video 
                    ref={videoRef} 
                    autoPlay 
                    playsInline 
                    muted 
                    className={`w-full h-full object-cover ${!cameraActive ? 'hidden' : ''}`}
                  />
                  <canvas 
                    ref={canvasRef} 
                    className="absolute inset-0 w-full h-full opacity-0" 
                  />
                  
                  {isProcessingGesture && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/70 backdrop-blur-sm">
                      <div className="bg-card/80 p-4 rounded-lg text-center backdrop-blur-md border border-white/10">
                        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-2"></div>
                        <p>Processing sign language...</p>
                      </div>
                    </div>
                  )}
                  
                  {isCapturing && !isProcessingGesture && (
                    <div className="absolute top-4 right-4 bg-destructive/90 text-white text-xs px-3 py-1 rounded-full animate-pulse flex items-center">
                      <span className="w-2 h-2 bg-white rounded-full mr-2"></span>
                      Recording
                    </div>
                  )}
                </Card>
                
                <Card className="p-4 glass-card border border-white/10 bg-gradient-to-r from-background/30 to-card/30">
                  <h3 className="text-sm font-medium mb-3">Capture Settings</h3>
                  
                  <div className="space-y-4">
                    <div>
                      <p className="text-xs text-muted-foreground mb-2">Capture Mode:</p>
                      <ToggleGroup 
                        type="single" 
                        variant="outline"
                        value={captureMode}
                        onValueChange={(value) => {
                          if (value) setCaptureMode(value as 'continuous' | 'manual');
                        }}
                        className="justify-start"
                      >
                        <ToggleGroupItem value="continuous" className="text-xs">
                          Continuous
                        </ToggleGroupItem>
                        <ToggleGroupItem value="manual" className="text-xs">
                          Manual
                        </ToggleGroupItem>
                      </ToggleGroup>
                    </div>
                    
                    {captureMode === 'continuous' && (
                      <div>
                        <p className="text-xs text-muted-foreground mb-2">Capture Speed:</p>
                        <ToggleGroup 
                          type="single" 
                          variant="outline"
                          value={
                            captureInterval === 8000 ? 'slow' : 
                            captureInterval === 5000 ? 'medium' : 'fast'
                          }
                          onValueChange={(value) => {
                            if (value) setCaptureSpeed(value as 'slow' | 'medium' | 'fast');
                          }}
                          className="justify-start"
                        >
                          <ToggleGroupItem value="slow" className="text-xs">Slow</ToggleGroupItem>
                          <ToggleGroupItem value="medium" className="text-xs">Medium</ToggleGroupItem>
                          <ToggleGroupItem value="fast" className="text-xs">Fast</ToggleGroupItem>
                        </ToggleGroup>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex gap-4 mt-4">
                    {!cameraActive ? (
                      <Button 
                        onClick={handleStartCamera} 
                        className="flex-1 sign-btn sign-btn-primary bg-gradient-to-r from-primary to-primary/80 hover:opacity-90"
                      >
                        <Video className="h-5 w-5 mr-2" />
                        Activate Camera
                      </Button>
                    ) : (
                      <Button 
                        onClick={handleStopCamera} 
                        className="flex-1 sign-btn border-primary/60 text-primary" 
                        variant="outline"
                      >
                        <VideoOff className="h-5 w-5 mr-2" />
                        Deactivate Camera
                      </Button>
                    )}
                    
                    <Button 
                      onClick={toggleCaptureMode} 
                      className={cn(
                        "flex-1 sign-btn",
                        isCapturing 
                          ? "bg-destructive text-destructive-foreground hover:bg-destructive/90 shadow-lg shadow-destructive/30" 
                          : captureMode === 'continuous'
                            ? "sign-btn-secondary bg-gradient-to-r from-secondary to-secondary/80 hover:opacity-90"
                            : "bg-accent text-accent-foreground hover:bg-accent/90 shadow-lg shadow-accent/30"
                      )}
                      disabled={!cameraActive && !isCapturing}
                    >
                      <HandMetal className="h-5 w-5 mr-2" />
                      {isCapturing 
                        ? 'Stop Capturing' 
                        : captureMode === 'continuous' 
                          ? 'Start Continuous Capture' 
                          : 'Capture Sign'
                      }
                    </Button>
                  </div>
                </Card>
                
                <Card className="p-4 glass-card border border-white/10 bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5">
                  <h3 className="font-semibold mb-3 text-gradient animate-text-shimmer flex items-center">
                    <Info className="h-4 w-4 mr-2" />
                    Using Sign Language Chat
                  </h3>
                  <ul className="space-y-3 text-sm text-foreground">
                    <li className="flex items-start">
                      <span className="bg-secondary/30 backdrop-blur-sm rounded-full p-1 mr-2 mt-0.5 w-5 h-5 flex items-center justify-center text-xs border border-white/10">1</span>
                      <span>Activate your camera to use sign language</span>
                    </li>
                    <li className="flex items-start">
                      <span className="bg-secondary/30 backdrop-blur-sm rounded-full p-1 mr-2 mt-0.5 w-5 h-5 flex items-center justify-center text-xs border border-white/10">2</span>
                      <span>Select continuous or manual capture mode</span>
                    </li>
                    <li className="flex items-start">
                      <span className="bg-secondary/30 backdrop-blur-sm rounded-full p-1 mr-2 mt-0.5 w-5 h-5 flex items-center justify-center text-xs border border-white/10">3</span>
                      <span>Click the capture button and make signs clearly</span>
                    </li>
                    <li className="flex items-start">
                      <span className="bg-secondary/30 backdrop-blur-sm rounded-full p-1 mr-2 mt-0.5 w-5 h-5 flex items-center justify-center text-xs border border-white/10">4</span>
                      <span>Ask questions from the FAQ catalog or browse topics</span>
                    </li>
                  </ul>
                  
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="mt-3 w-full text-xs bg-black/20 border-white/10"
                    onClick={toggleFAQView}
                  >
                    <Lightbulb className="h-4 w-4 mr-2 text-yellow-400" />
                    {showFAQ ? 'Back to Camera' : 'Browse Sign Language FAQs'}
                  </Button>
                </Card>
              </>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default ChatbotPage;
